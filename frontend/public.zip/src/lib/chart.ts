import type {
  ChartConfig,
  ChartType,
  DatasetColumn,
  LayoutColumn,
  ReportLayout,
  ReportResult,
} from '../api/types'
import { emptyLayout } from '../api/types'

export const CHART_TYPES: ChartType[] = ['bar', 'line', 'area', 'pie', 'doughnut']

export const CHART_TYPE_KEYS: Record<ChartType, 'chartBar' | 'chartLine' | 'chartArea' | 'chartPie' | 'chartDoughnut'> =
  {
    bar: 'chartBar',
    line: 'chartLine',
    area: 'chartArea',
    pie: 'chartPie',
    doughnut: 'chartDoughnut',
  }

const NUMERIC_TYPES = new Set([
  'int',
  'bigint',
  'smallint',
  'tinyint',
  'decimal',
  'numeric',
  'money',
  'smallmoney',
  'float',
  'real',
])

export function isNumericSqlType(sqlType: string) {
  return NUMERIC_TYPES.has(sqlType.toLowerCase())
}

export function isChartLayout(layout: ReportLayout | null | undefined) {
  return layout?.kind === 'chart'
}

export function defaultChartConfig(type: ChartType = 'bar'): ChartConfig {
  return {
    type,
    stacked: false,
    showLegend: true,
    showDataLabels: false,
  }
}

export function emptyChartLayout(type: ChartType = 'bar'): ReportLayout {
  return {
    kind: 'chart',
    columns: [],
    groupBy: [],
    filters: [],
    orderBy: [],
    chart: defaultChartConfig(type),
  }
}

export function normalizeLayout(layout: ReportLayout): ReportLayout {
  const kind = layout.kind === 'chart' ? 'chart' : 'table'
  const base = emptyLayout()
  return {
    ...base,
    ...layout,
    kind,
    columns: layout.columns ?? [],
    groupBy: layout.groupBy ?? [],
    filters: layout.filters ?? [],
    orderBy: layout.orderBy ?? [],
    chart: kind === 'chart' ? { ...defaultChartConfig(), ...layout.chart } : layout.chart ?? null,
    userScope: layout.userScope ?? null,
  }
}

export function chartCategory(layout: ReportLayout) {
  return layout.groupBy[0] ?? ''
}

export function chartSeriesField(layout: ReportLayout) {
  return layout.groupBy[1] ?? ''
}

export function chartMeasures(layout: ReportLayout) {
  return layout.columns.filter((column) => Boolean(column.aggregate))
}

export function withChartConfig(layout: ReportLayout, chart: Partial<ChartConfig>): ReportLayout {
  const type = chart.type ?? layout.chart?.type ?? 'bar'
  const next: ChartConfig = {
    ...defaultChartConfig(type),
    ...layout.chart,
    ...chart,
    type,
  }
  const series = type === 'pie' || type === 'doughnut' ? '' : chartSeriesField(layout)
  return withChartPicks(layout, {
    category: chartCategory(layout),
    series,
    measures: chartMeasures(layout),
    chart: next,
  })
}

export function withChartPicks(
  layout: ReportLayout,
  picks: {
    category: string
    series?: string
    measures: LayoutColumn[]
    chart?: ChartConfig
  },
): ReportLayout {
  const chart = { ...defaultChartConfig(), ...layout.chart, ...picks.chart }
  const pie = chart.type === 'pie' || chart.type === 'doughnut'
  const category = picks.category
  const series = pie ? '' : picks.series && picks.series !== category ? picks.series : ''
  const groupBy = [category, series].filter(Boolean)
  const grouped = new Set(groupBy)
  const measures = picks.measures.filter(
    (measure) => measure.field && measure.aggregate && !grouped.has(measure.field),
  )
  const columns: LayoutColumn[] = [
    ...groupBy.map((field) => ({ field })),
    ...measures.map((measure) => ({
      field: measure.field,
      alias: measure.alias,
      aggregate: measure.aggregate,
      format: measure.format,
      locale: measure.locale,
      urlTemplate: measure.urlTemplate,
      conditionalFormat: measure.conditionalFormat,
    })),
  ]
  return {
    ...layout,
    kind: 'chart',
    groupBy,
    columns,
    chart,
  }
}

export function suggestedAggregate(column: DatasetColumn) {
  return isNumericSqlType(column.sqlType) ? 'SUM' : 'COUNT'
}

export function resultColumnName(result: ReportResult, field: string, alias?: string | null) {
  const wanted = (alias?.trim() || field).toLowerCase()
  const match = result.columns.find(
    (column) =>
      column.name.toLowerCase() === wanted || column.label.toLowerCase() === wanted,
  )
  return match?.name ?? alias?.trim() ?? field
}

export function cellNumber(value: unknown) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value
  }
  if (typeof value === 'string' && value.trim()) {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : 0
  }
  return 0
}

export function cellLabel(value: unknown, emptyLabel: string) {
  if (value == null || value === '') {
    return emptyLabel
  }
  if (value instanceof Date) {
    return value.toISOString().slice(0, 10)
  }
  return String(value)
}
