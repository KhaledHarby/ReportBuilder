import type { DatasetColumn, LayoutFilter, ReportLayout } from '../api/types'
import { needsFilterValue } from './filters'

const RESERVED_QUERY_KEYS = new Set(['lang', 'skip', 'take', 'format'])

export function appBasePath() {
  const base = import.meta.env.BASE_URL.replace(/\/+$/, '')
  return base === '/' ? '' : base
}

/** Prefix the Vite/IIS app path so /reports/... works under /ReportBuilder. */
export function resolveAppHref(href: string) {
  const trimmed = href.trim()
  if (!trimmed.startsWith('/') || trimmed.startsWith('//')) {
    return trimmed
  }

  const base = appBasePath()
  if (!base) {
    return trimmed
  }
  if (trimmed === base || trimmed.startsWith(`${base}/`)) {
    return trimmed
  }
  return `${base}${trimmed}`
}

export function cellLinkProps(href: string) {
  return { href, target: '_blank' as const, rel: 'noreferrer' }
}

export function buildReportDrillthroughUrl(
  reportId: string,
  sourceField: string,
  targetField?: string,
) {
  const target = (targetField ?? sourceField).trim()
  if (!target) {
    return `/reports/${reportId}/view`
  }
  const token = `{${sourceField}}`
  const query = `${encodeURIComponent(target)}=${token}`
  return `/reports/${reportId}/view?${query}`
}

export function reportIdFromUrlTemplate(template: string | null | undefined) {
  const match = template?.trim().match(/\/reports\/([^/?#]+)\/view(?:\?|$|#)/i)
  return match?.[1] ?? ''
}

export function drillthroughTargetField(template: string | null | undefined) {
  const match = template?.trim().match(/\/view\?([^#]*)/i)
  if (!match) {
    return ''
  }
  const params = new URLSearchParams(match[1])
  for (const [key] of params.entries()) {
    if (!RESERVED_QUERY_KEYS.has(key.toLowerCase()) && key.trim()) {
      return key.trim()
    }
  }
  return ''
}

export function allowedDrillthroughFields(
  layout?: ReportLayout | null,
  columns?: Array<Pick<DatasetColumn, 'columnName' | 'isHidden'>> | null,
) {
  const fields = new Set<string>()
  const add = (field?: string | null) => {
    const name = field?.trim()
    if (name) {
      fields.add(name)
    }
  }
  for (const filter of layout?.filters ?? []) {
    add(filter.field)
  }
  for (const column of layout?.columns ?? []) {
    add(column.field)
  }
  for (const field of layout?.groupBy ?? []) {
    add(field)
  }
  for (const column of columns ?? []) {
    if (!column.isHidden) {
      add(column.columnName)
    }
  }
  return fields
}

export function resolveDrillthroughField(allowed: Set<string>, key: string) {
  return canonicalField(allowed, key)
}

export function unusedDrillthroughKeys(params: URLSearchParams, allowed: Set<string>) {
  const unused: string[] = []
  const seen = new Set<string>()
  for (const [key] of params.entries()) {
    if (RESERVED_QUERY_KEYS.has(key.toLowerCase()) || !key.trim()) {
      continue
    }
    const lower = key.trim().toLowerCase()
    if (seen.has(lower)) {
      continue
    }
    seen.add(lower)
    if (!canonicalField(allowed, key)) {
      unused.push(key.trim())
    }
  }
  return unused
}

function canonicalField(allowed: Set<string>, key: string) {
  const lower = key.trim().toLowerCase()
  if (!lower) {
    return null
  }
  for (const field of allowed) {
    if (field.toLowerCase() === lower) {
      return field
    }
  }
  return null
}

function queryValue(params: URLSearchParams, field: string) {
  const lower = field.toLowerCase()
  const values: string[] = []
  for (const [key, value] of params.entries()) {
    if (RESERVED_QUERY_KEYS.has(key.toLowerCase())) {
      continue
    }
    if (key.toLowerCase() === lower && value.trim()) {
      values.push(value.trim())
    }
  }
  if (values.length === 0) {
    return null
  }
  return values.join(',')
}

export function applyQueryParamsToFilters(
  saved: LayoutFilter[],
  params: URLSearchParams,
  allowedFields: Set<string>,
): LayoutFilter[] | null {
  if ([...params.keys()].every((key) => RESERVED_QUERY_KEYS.has(key.toLowerCase()))) {
    return null
  }

  const used = new Set<string>()
  const next = saved.map((filter) => {
    const value = queryValue(params, filter.field)
    if (value == null) {
      return { ...filter }
    }
    used.add(filter.field.trim().toLowerCase())
    const operator = needsFilterValue(filter.operator) ? filter.operator : 'eq'
    return { ...filter, operator, value }
  })

  for (const [key] of params.entries()) {
    if (RESERVED_QUERY_KEYS.has(key.toLowerCase())) {
      continue
    }
    const field = canonicalField(allowedFields, key)
    if (!field || used.has(field.toLowerCase())) {
      continue
    }
    const value = queryValue(params, field)
    if (!value) {
      continue
    }
    used.add(field.toLowerCase())
    next.push({
      field,
      operator: 'eq',
      value,
      isHidden: true,
    })
  }

  const changed =
    next.length !== saved.length ||
    next.some(
      (filter, index) =>
        filter.value !== saved[index]?.value || filter.operator !== saved[index]?.operator,
    )
  return changed ? next : null
}
