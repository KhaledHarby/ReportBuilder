import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useMemo, useState, type ReactNode } from 'react'
import { api } from '../api/client'
import type { RoleRecord } from '../api/types'
import { useAuth } from '../auth/AuthProvider'
import { AuditLine, Field, PermissionPicker } from '../components/AdminFields'
import { IconPlus } from '../components/Icons'
import { Spinner } from '../components/Spinner'
import { useLocale } from '../i18n/LocaleProvider'

const emptyForm = {
  name: '',
  description: '',
  permissionIds: [] as string[],
}

export function RolesPage() {
  const { can } = useAuth()
  const { t } = useLocale()
  const queryClient = useQueryClient()
  const roles = useQuery({ queryKey: ['roles'], queryFn: api.listRoles })
  const permissions = useQuery({
    queryKey: ['permissions'],
    queryFn: api.listPermissions,
    enabled: can('permissions.view'),
  })
  const [filter, setFilter] = useState('')
  const [openId, setOpenId] = useState<string | 'new' | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [error, setError] = useState<string | null>(null)

  const canCreate = can('roles.create')
  const canUpdate = can('roles.update')
  const canDelete = can('roles.delete')

  const visible = useMemo(() => {
    const list = roles.data ?? []
    const q = filter.trim().toLowerCase()
    if (!q) {
      return list
    }
    return list.filter((item) =>
      `${item.name} ${item.description ?? ''}`.toLowerCase().includes(q),
    )
  }, [roles.data, filter])

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        name: form.name,
        description: form.description || undefined,
        permissionIds: form.permissionIds,
      }
      return openId === 'new'
        ? api.createRole(payload)
        : api.updateRole(openId!, payload)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] })
      setOpenId(null)
      setError(null)
    },
    onError: (err) => setError((err as Error).message),
  })

  function startEdit(role: RoleRecord) {
    setForm({
      name: role.name,
      description: role.description ?? '',
      permissionIds: role.permissionIds,
    })
    setOpenId(role.id)
    setError(null)
  }

  return (
    <section className="page">
      <header className="page-header">
        <div>
          <div className="kicker">{t('identityKicker')}</div>
          <h1>{t('rolesTitle')}</h1>
          <p className="lede">{t('rolesLede')}</p>
        </div>
        {canCreate && (
          <button
            type="button"
            className="btn primary"
            onClick={() => {
              setForm(emptyForm)
              setOpenId('new')
            }}
          >
            <IconPlus />
            {t('newRole')}
          </button>
        )}
      </header>

      {(roles.isError || error) && (
        <div className="banner error">
          {error || (roles.error as Error).message}
        </div>
      )}

      <div className="page-header">
        <h2>{t('roles')}</h2>
        <input
          className="search"
          placeholder={t('filterRoles')}
          value={filter}
          onChange={(event) => setFilter(event.target.value)}
        />
      </div>

      {openId === 'new' && (
        <RoleForm
          title={t('newRole')}
          form={form}
          setForm={setForm}
          permissions={permissions.data ?? []}
          canSave
          pending={save.isPending}
          onCancel={() => setOpenId(null)}
          onSave={() => save.mutate()}
        />
      )}

      {roles.isLoading ? (
        <Spinner page label={t('loadingApp')} />
      ) : (
        <div className="catalog-grid">
          {visible.map((role) => (
            <article
              key={role.id}
              className={`catalog-card ${role.isSystem ? 'enabled' : ''}`}
            >
              <div className="catalog-top">
                <div>
                  <button
                    type="button"
                    className="link"
                    onClick={() =>
                      openId === role.id ? setOpenId(null) : startEdit(role)
                    }
                  >
                    {role.name}
                  </button>
                  <div className="object-name">
                    {t('userCount', {
                      n: role.userCount,
                      label: role.userCount === 1 ? t('userSingular') : t('userPlural'),
                    })}{' '}
                    · {t('permissionCount', { n: role.permissions.length })}
                  </div>
                </div>
                {role.isSystem && <span className="badge table">{t('system')}</span>}
              </div>
              <p className="muted small">
                {role.description || t('noDescription')}
              </p>
              {openId === role.id && (
                <RoleForm
                  title={t('editRole')}
                  form={form}
                  setForm={setForm}
                  permissions={permissions.data ?? []}
                  canSave={canUpdate}
                  pending={save.isPending}
                  onCancel={() => setOpenId(null)}
                  onSave={() => save.mutate()}
                  extra={
                    canDelete && !role.isSystem ? (
                      <button
                        type="button"
                        className="btn danger"
                        onClick={async () => {
                          if (!confirm(t('deleteRoleConfirm', { name: role.name }))) {
                            return
                          }
                          try {
                            await api.deleteRole(role.id)
                            queryClient.invalidateQueries({ queryKey: ['roles'] })
                            setOpenId(null)
                          } catch (err) {
                            setError((err as Error).message)
                          }
                        }}
                      >
                        {t('delete')}
                      </button>
                    ) : null
                  }
                  audit={role}
                />
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  )
}

function RoleForm({
  title,
  form,
  setForm,
  permissions,
  canSave,
  pending,
  onCancel,
  onSave,
  extra,
  audit,
}: {
  title: string
  form: typeof emptyForm
  setForm: (form: typeof emptyForm) => void
  permissions: Parameters<typeof PermissionPicker>[0]['permissions']
  canSave: boolean
  pending: boolean
  onCancel: () => void
  onSave: () => void
  extra?: ReactNode
  audit?: RoleRecord
}) {
  const { t } = useLocale()
  return (
    <div className="admin-form">
      <h3>{title}</h3>
      <div className="admin-grid">
        <Field label={t('name')}>
          <input
            value={form.name}
            onChange={(event) => setForm({ ...form, name: event.target.value })}
          />
        </Field>
        <Field label={t('description')}>
          <input
            value={form.description}
            onChange={(event) =>
              setForm({ ...form, description: event.target.value })
            }
          />
        </Field>
      </div>
      <h3>{t('permissions')}</h3>
      <PermissionPicker
        permissions={permissions}
        selected={form.permissionIds}
        onChange={(permissionIds) => setForm({ ...form, permissionIds })}
      />
      {audit && <AuditLine {...audit} />}
      <div className="row-actions">
        {canSave && (
          <button
            type="button"
            className="btn primary"
            disabled={pending}
            onClick={onSave}
          >
            {pending ? t('saving') : t('save')}
          </button>
        )}
        <button type="button" className="btn" onClick={onCancel}>
          {t('cancel')}
        </button>
        {extra}
      </div>
    </div>
  )
}
