import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ConditionalFormatRule, ReportResult } from '../api/types'
import { interpolateUrl } from '../lib/analyticsFilters'
import { cellLinkProps } from '../lib/reportLinks'
import { formatColumnValue } from '../lib/columnFormat'
import { resolveConditionalStyle } from '../lib/conditionalFormat'
import { IconColumns } from './Icons'
import { Spinner } from './Spinner'
import { useLocale } from '../i18n/LocaleProvider'

type SortDir = 'asc' | 'desc'

const MIN_COLUMN_WIDTH = 72
const MAX_COLUMN_WIDTH = 420
const COLUMN_PADDING = 24
const SORT_ICON_WIDTH = 22
type Props = {
  result: ReportResult | null
  loading?: boolean
  error?: string | null
  emptyHint?: string
  allowSort?: boolean
  align?: 'start' | 'center'
  fillWidth?: boolean
  /** Measure header/cell content and size columns on load (and when data changes). */
  autoFit?: boolean
  columnFormats?: Record<string, string | null | undefined>
  columnUrls?: Record<string, string | undefined>
  columnConditionalFormats?: Record<string, ConditionalFormatRule[] | undefined>
  urlTokens?: { id: string; field?: string; label: string }[]
  /** Controlled sort, used with onSortChange for server-side ordering. */
  sort?: { column: string; dir: SortDir } | null
  onSortChange?: (sort: { column: string; dir: SortDir } | null) => void
  onPageChange: (skip: number) => void
}

function formatCell(
  value: unknown,
  locale: string,
  format?: string | null,
) {
  return formatColumnValue(value, format, locale)
}

function isEmpty(value: unknown) {
  return value == null || value === ''
}

function compareValues(left: unknown, right: unknown) {
  if (isEmpty(left) && isEmpty(right)) {
    return 0
  }
  if (isEmpty(left)) {
    return 1
  }
  if (isEmpty(right)) {
    return -1
  }

  if (typeof left === 'number' && typeof right === 'number') {
    return left - right
  }

  const leftText = String(left)
  const rightText = String(right)
  const leftNumber = Number(leftText)
  const rightNumber = Number(rightText)
  if (
    leftText.trim() !== '' &&
    rightText.trim() !== '' &&
    Number.isFinite(leftNumber) &&
    Number.isFinite(rightNumber)
  ) {
    return leftNumber - rightNumber
  }

  const leftDate = Date.parse(leftText)
  const rightDate = Date.parse(rightText)
  if (
    Number.isFinite(leftDate) &&
    Number.isFinite(rightDate) &&
    /\d/.test(leftText) &&
    /[-/T]/.test(leftText)
  ) {
    return leftDate - rightDate
  }

  return leftText.localeCompare(rightText, undefined, {
    numeric: true,
    sensitivity: 'base',
  })
}

let measureNode: HTMLSpanElement | null = null

function measureTextWidth(text: string, font: string, letterSpacing = 'normal') {
  if (typeof document === 'undefined') {
    return text.length * 8
  }
  if (!measureNode) {
    measureNode = document.createElement('span')
    measureNode.style.position = 'absolute'
    measureNode.style.visibility = 'hidden'
    measureNode.style.whiteSpace = 'nowrap'
    measureNode.style.left = '-9999px'
    document.body.appendChild(measureNode)
  }
  measureNode.style.font = font
  measureNode.style.letterSpacing = letterSpacing
  measureNode.textContent = text
  return measureNode.getBoundingClientRect().width
}

function readTableFonts(table: HTMLTableElement | null) {
  const header = table?.querySelector('thead th')
  const body = table?.querySelector('tbody td')
  const headerStyle = header ? getComputedStyle(header) : null
  const bodyStyle = body ? getComputedStyle(body) : null
  const headerFont = headerStyle
    ? `${headerStyle.fontWeight} ${headerStyle.fontSize} ${headerStyle.fontFamily}`
    : '700 11px Outfit, "Segoe UI", sans-serif'
  const bodyFont = bodyStyle
    ? `${bodyStyle.fontWeight} ${bodyStyle.fontSize} ${bodyStyle.fontFamily}`
    : '400 14px Outfit, "Segoe UI", sans-serif'
  const headerLetterSpacing = headerStyle?.letterSpacing ?? '0.08em'
  return { headerFont, bodyFont, headerLetterSpacing }
}

function spreadColumnWidths(
  columns: ReportResult['columns'],
  containerWidth: number,
  source: Record<string, number> | null,
) {
  if (columns.length === 0 || containerWidth <= 0) {
    return {}
  }

  const next: Record<string, number> = {}

  if (!source || Object.keys(source).length === 0) {
    let used = 0
    columns.forEach((column, index) => {
      const width =
        index === columns.length - 1
          ? Math.max(MIN_COLUMN_WIDTH, containerWidth - used)
          : Math.max(MIN_COLUMN_WIDTH, Math.floor(containerWidth / columns.length))
      next[column.name] = width
      used += width
    })
    return next
  }

  const minTotal = columns.reduce((sum, column) => sum + source[column.name], 0)
  if (minTotal >= containerWidth) {
    return source
  }

  let used = 0
  const scale = containerWidth / minTotal
  columns.forEach((column, index) => {
    const width =
      index === columns.length - 1
        ? Math.max(MIN_COLUMN_WIDTH, containerWidth - used)
        : Math.max(MIN_COLUMN_WIDTH, Math.ceil(source[column.name] * scale))
    next[column.name] = width
    used += width
  })
  return next
}

export function ResultGrid({
  result,
  loading,
  error,
  emptyHint,
  allowSort = false,
  align = 'start',
  fillWidth = false,
  autoFit = false,
  columnFormats,
  columnUrls,
  columnConditionalFormats,
  urlTokens,
  sort: sortProp,
  onSortChange,
  onPageChange,
}: Props) {
  const { locale, t } = useLocale()
  const [clientSort, setClientSort] = useState<{ column: string; dir: SortDir } | null>(null)
  const serverSort = Boolean(onSortChange)
  const sortEnabled = allowSort || serverSort
  const sort = serverSort ? (sortProp ?? null) : clientSort
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({})
  const tableRef = useRef<HTMLTableElement>(null)
  const tableScrollRef = useRef<HTMLDivElement>(null)
  const fitWidthsRef = useRef<Record<string, number> | null>(null)

  const displayColumns = useMemo(
    () => (result?.columns ?? []).filter((column) => !column.hidden),
    [result],
  )
  const columnKey = displayColumns.map((column) => column.name).join('\0')

  const resolveFormat = useCallback(
    (columnName: string) => columnFormats?.[columnName] ?? null,
    [columnFormats],
  )

  const resolveRules = useCallback(
    (columnName: string) =>
      columnConditionalFormats?.[columnName] ??
      Object.entries(columnConditionalFormats ?? {}).find(
        ([name]) => name.toLowerCase() === columnName.toLowerCase(),
      )?.[1],
    [columnConditionalFormats],
  )

  useEffect(() => {
    fitWidthsRef.current = null
    setColumnWidths({})
  }, [columnKey])

  const rows = useMemo(() => {
    const source = result?.rows ?? []
    if (serverSort || !allowSort || !sort) {
      return source
    }

    const next = source.slice()
    next.sort((a, b) => {
      const rank = compareValues(a[sort.column], b[sort.column])
      return sort.dir === 'asc' ? rank : -rank
    })
    return next
  }, [allowSort, result?.rows, serverSort, sort])

  const layoutFilledWidths = useCallback(() => {
    if (!fillWidth || !result || !tableScrollRef.current) {
      return
    }

    // Wait for content-based auto-fit before spreading equal widths.
    if (autoFit && !fitWidthsRef.current) {
      return
    }

    setColumnWidths(
      spreadColumnWidths(
        displayColumns,
        tableScrollRef.current.clientWidth,
        fitWidthsRef.current,
      ),
    )
  }, [autoFit, displayColumns, fillWidth, result])

  useEffect(() => {
    if (!fillWidth || !result) {
      return
    }

    layoutFilledWidths()
    const node = tableScrollRef.current
    if (!node) {
      return
    }

    const observer = new ResizeObserver(() => layoutFilledWidths())
    observer.observe(node)
    return () => observer.disconnect()
  }, [fillWidth, result, columnKey, layoutFilledWidths])

  const bestFitColumns = useCallback(() => {
    if (!result) {
      return
    }

    const { headerFont, bodyFont, headerLetterSpacing } = readTableFonts(tableRef.current)
    const sortExtra = sortEnabled ? SORT_ICON_WIDTH : 0
    const next: Record<string, number> = {}

    for (const column of displayColumns) {
      let width =
        measureTextWidth(column.label, headerFont, headerLetterSpacing) +
        COLUMN_PADDING +
        sortExtra

      for (const row of rows) {
        const text = formatCell(
          row[column.name],
          locale,
          resolveFormat(column.name),
        )
        width = Math.max(
          width,
          measureTextWidth(text, bodyFont) + COLUMN_PADDING,
        )
      }

      next[column.name] = Math.min(
        MAX_COLUMN_WIDTH,
        Math.max(MIN_COLUMN_WIDTH, Math.ceil(width)),
      )
    }

    fitWidthsRef.current = next
    if (fillWidth && tableScrollRef.current) {
      setColumnWidths(
        spreadColumnWidths(
          displayColumns,
          tableScrollRef.current.clientWidth,
          next,
        ),
      )
      return
    }

    setColumnWidths(next)
  }, [displayColumns, fillWidth, locale, resolveFormat, result, rows, sortEnabled])

  useEffect(() => {
    if (!autoFit || !result) {
      return
    }

    const frame = requestAnimationFrame(() => {
      bestFitColumns()
    })
    return () => cancelAnimationFrame(frame)
  }, [autoFit, bestFitColumns, columnKey, result, rows])

  const hasColumnWidths = Object.keys(columnWidths).length > 0

  if (error) {
    return <div className="banner error">{error}</div>
  }

  if (!result && loading) {
    return <Spinner page label={t('loadingApp')} />
  }

  if (!result) {
    return (
      <div className="empty">
        <IconColumns />
        <div className="kicker">{t('preview')}</div>
        <h2>{t('gridWaiting')}</h2>
        <p>{emptyHint ?? t('dropToQuery')}</p>
      </div>
    )
  }

  const from = result.totalCount === 0 ? 0 : result.skip + 1
  const to = Math.min(result.skip + result.rows.length, result.totalCount)
  const paging = loading && Boolean(result)

  const toggleSort = (column: string) => {
    const next =
      sort?.column !== column
        ? { column, dir: 'asc' as const }
        : sort.dir === 'asc'
          ? { column, dir: 'desc' as const }
          : { column, dir: 'asc' as const }
    if (onSortChange) {
      onSortChange(next)
      return
    }
    setClientSort(next)
  }

  return (
    <div className="grid-wrap">
      <div className={`table-scroll${paging ? ' is-paging' : ''}`} ref={tableScrollRef}>
        {paging ? <Spinner overlay label={t('loadingApp')} /> : null}
        <table
          ref={tableRef}
          className={`data-table${hasColumnWidths ? ' sized' : ''}${align === 'center' ? ' centered' : ''}${fillWidth ? ' fill-width' : ''}`}
        >
          {hasColumnWidths && (
            <colgroup>
              {displayColumns.map((column) => (
                <col
                  key={column.name}
                  style={{ width: columnWidths[column.name] }}
                />
              ))}
            </colgroup>
          )}
          <thead>
            <tr>
              {displayColumns.map((column) => {
                const active = sort?.column === column.name
                const ariaSort = !sortEnabled
                  ? undefined
                  : active
                    ? sort?.dir === 'asc'
                      ? 'ascending'
                      : 'descending'
                    : 'none'
                return (
                  <th key={column.name} aria-sort={ariaSort}>
                    {sortEnabled ? (
                      <button
                        type="button"
                        className={`th-sort ${active ? 'active' : ''}`}
                        onClick={() => toggleSort(column.name)}
                      >
                        <span>{column.label}</span>
                        <span className="th-sort-icon" aria-hidden="true">
                          {active ? (sort?.dir === 'asc' ? '↑' : '↓') : '↕'}
                        </span>
                      </button>
                    ) : (
                      column.label
                    )}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={Math.max(displayColumns.length, 1)} className="muted">
                  {t('noRows')}
                </td>
              </tr>
            ) : (
              rows.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {displayColumns.map((column) => {
                    const text = formatCell(
                      row[column.name],
                      locale,
                      resolveFormat(column.name),
                    )
                    const template =
                      columnUrls?.[column.name] ??
                      Object.entries(columnUrls ?? {}).find(
                        ([name]) => name.toLowerCase() === column.name.toLowerCase(),
                      )?.[1]
                    const href = template
                      ? interpolateUrl(
                          template,
                          row,
                          urlTokens ??
                            result.columns.map((item) => ({
                              id: item.name,
                              field: item.name,
                              label: item.label,
                            })),
                          column.name,
                        )
                      : null
                    const cf = resolveConditionalStyle(
                      row[column.name],
                      resolveRules(column.name),
                    )
                    const className = [
                      href ? 'has-cell-link' : '',
                      cf?.backgroundColor ? 'cf-cell' : '',
                    ]
                      .filter(Boolean)
                      .join(' ')
                    return (
                      <td
                        key={column.name}
                        className={className || undefined}
                        style={
                          cf
                            ? {
                                backgroundColor: cf.backgroundColor,
                                color: cf.color,
                                fontWeight: cf.fontWeight,
                                ...(cf.backgroundColor
                                  ? { ['--cf-fill']: cf.backgroundColor }
                                  : {}),
                              }
                            : undefined
                        }
                      >
                        {href ? (
                          <a
                            className="cell-link"
                            {...cellLinkProps(href)}
                            style={
                              cf?.color || cf?.fontWeight
                                ? { color: cf.color, fontWeight: cf.fontWeight }
                                : undefined
                            }
                          >
                            {text}
                          </a>
                        ) : (
                          text
                        )}
                      </td>
                    )
                  })}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div className="pager">
        <span className="muted">
          {t('pagerRange', {
            from,
            to,
            total: result.totalCount.toLocaleString(locale),
          })}
          {loading ? t('refreshing') : ''}
          {allowSort && !serverSort && sort ? t('sortedPage') : ''}
        </span>
        <div className="pager-actions">
          {paging ? <Spinner size="sm" label={t('loadingApp')} /> : null}
          <button
            type="button"
            className="btn"
            disabled={result.skip === 0 || paging}
            onClick={() => onPageChange(Math.max(0, result.skip - result.take))}
          >
            {t('previous')}
          </button>
          <button
            type="button"
            className="btn"
            disabled={result.skip + result.take >= result.totalCount || paging}
            onClick={() => onPageChange(result.skip + result.take)}
          >
            {t('next')}
          </button>
        </div>
      </div>
    </div>
  )
}
