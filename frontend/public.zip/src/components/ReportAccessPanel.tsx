import { useMemo, useState } from 'react'
import type { ReportPerson } from '../api/types'
import { useLocale } from '../i18n/LocaleProvider'
import { localizedText } from '../i18n/localized'

type Props = {
  isRestricted: boolean
  accessUserIds: string[]
  people: ReportPerson[]
  loading?: boolean
  currentUserId?: string | null
  heading?: string
  hint?: string
  accessLabel?: string
  onRestrictedChange: (restricted: boolean) => void
  onAccessUserIdsChange: (ids: string[]) => void
  disabled?: boolean
}

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length >= 2) {
    return `${parts[0][0] ?? ''}${parts[1][0] ?? ''}`.toUpperCase()
  }
  return (name.trim().slice(0, 2) || '?').toUpperCase()
}

export function ReportAccessPanel({
  isRestricted,
  accessUserIds,
  people,
  loading = false,
  currentUserId,
  heading,
  hint,
  accessLabel,
  onRestrictedChange,
  onAccessUserIdsChange,
  disabled = false,
}: Props) {
  const { lang, t } = useLocale()
  const [query, setQuery] = useState('')
  const selected = useMemo(() => new Set(accessUserIds), [accessUserIds])
  const selectedPeople = useMemo(
    () =>
      accessUserIds
        .map((id) => people.find((person) => person.id === id))
        .filter((person): person is ReportPerson => Boolean(person)),
    [accessUserIds, people],
  )
  const candidates = useMemo(() => {
    const q = query.trim().toLowerCase()
    return people
      .filter((person) => {
        if (person.id === currentUserId) {
          return false
        }
        if (!q) {
          return true
        }
        return (
          person.displayName.toLowerCase().includes(q) ||
          (person.displayNameArabic ?? '').toLowerCase().includes(q) ||
          person.userName.toLowerCase().includes(q)
        )
      })
      .sort((a, b) => {
        const aSelected = selected.has(a.id)
        const bSelected = selected.has(b.id)
        if (aSelected !== bSelected) {
          return aSelected ? -1 : 1
        }
        return localizedText(lang, a.displayName, a.displayNameArabic).localeCompare(
          localizedText(lang, b.displayName, b.displayNameArabic),
        )
      })
  }, [people, query, currentUserId, selected, lang])

  const toggle = (id: string) => {
    const next = new Set(selected)
    if (next.has(id)) {
      next.delete(id)
    } else {
      next.add(id)
    }
    onAccessUserIdsChange([...next])
  }

  return (
    <section className="access-card">
      <div>
        <div className="kicker">{heading ?? t('whoCanAccess')}</div>
        <p className="muted small">{hint ?? t('accessHint')}</p>
      </div>
      <div className="access-modes" role="tablist" aria-label={accessLabel ?? t('reportAccess')}>
        <button
          type="button"
          className={!isRestricted ? 'active' : ''}
          disabled={disabled}
          onClick={() => onRestrictedChange(false)}
        >
          {t('everyone')}
        </button>
        <button
          type="button"
          className={isRestricted ? 'active' : ''}
          disabled={disabled}
          onClick={() => onRestrictedChange(true)}
        >
          {t('selectedPeople')}
        </button>
      </div>
      {isRestricted && (
        <div className="access-people">
          <div className="access-people-toolbar">
            <span className="muted small">
              {selectedPeople.length
                ? t('selectedCount', { n: selectedPeople.length })
                : t('noneSelectedHint')}
            </span>
            {selectedPeople.length > 0 && (
              <button
                type="button"
                className="link"
                disabled={disabled}
                onClick={() => onAccessUserIdsChange([])}
              >
                {t('clear')}
              </button>
            )}
          </div>
          {selectedPeople.length > 0 && (
            <div className="access-chips" aria-label={t('selectedPeople')}>
              {selectedPeople.map((person) => {
                const label = localizedText(lang, person.displayName, person.displayNameArabic)
                return (
                <span key={person.id} className="access-chip">
                  <span className="access-avatar" aria-hidden="true">
                    {initials(label || person.userName)}
                  </span>
                  <span className="access-chip-name">{label}</span>
                  <button
                    type="button"
                    disabled={disabled}
                    aria-label={t('removeNamed', { name: label })}
                    onClick={() => toggle(person.id)}
                  >
                    <span aria-hidden="true">×</span>
                  </button>
                </span>
                )
              })}
            </div>
          )}
          <input
            className="search access-people-search"
            placeholder={t('searchPeople')}
            value={query}
            disabled={disabled}
            onChange={(event) => setQuery(event.target.value)}
          />
          <div className="access-people-list" role="list">
            {loading && <p className="muted small">{t('loadingPeople')}</p>}
            {!loading && candidates.length === 0 && (
              <p className="muted small">
                {people.every((person) => person.id === currentUserId)
                  ? t('noOtherUsers')
                  : t('noMatchingPeople')}
              </p>
            )}
            {candidates.map((person) => {
              const checked = selected.has(person.id)
              const label = localizedText(lang, person.displayName, person.displayNameArabic)
              return (
                <label
                  key={person.id}
                  className={`access-person${checked ? ' checked' : ''}`}
                  role="listitem"
                >
                  <span className="access-avatar" aria-hidden="true">
                    {initials(label || person.userName)}
                  </span>
                  <span className="access-person-copy">
                    <b>{label}</b>
                    <span className="muted small">{person.userName}</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={checked}
                    disabled={disabled}
                    onChange={() => toggle(person.id)}
                  />
                </label>
              )
            })}
          </div>
        </div>
      )}
    </section>
  )
}
