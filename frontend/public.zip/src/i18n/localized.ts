import type { DatasetColumn, ReportLayout, ReportResult } from '../api/types'
import type { Lang } from './locale'

export function localizedText(
  lang: Lang,
  english?: string | null,
  arabic?: string | null,
) {
  const ar = arabic?.trim() ?? ''
  if (lang === 'ar' && ar) {
    return ar
  }
  const en = english?.trim() ?? ''
  return en || ar
}

export function datasetOptionLabel(
  lang: Lang,
  dataset: {
    displayName: string
    displayNameArabic?: string | null
    objectName: string
    objectType?: string | null
  },
) {
  const name = localizedText(lang, dataset.displayName, dataset.displayNameArabic)
  const objectName = dataset.objectName.trim()
  if ((dataset.objectType ?? '').toLowerCase() === 'query') {
    return name || objectName
  }
  if (!name) {
    return objectName
  }
  if (!objectName || name === objectName) {
    return name
  }
  return `${name} (${objectName})`
}

export function columnLabel(
  lang: Lang,
  column: Pick<DatasetColumn, 'columnName' | 'displayName' | 'displayNameArabic'>,
  alias?: string | null,
) {
  if (alias?.trim()) {
    return alias.trim()
  }
  return localizedText(lang, column.displayName || column.columnName, column.displayNameArabic)
}

export function localizeResultColumns(
  lang: Lang,
  result: ReportResult,
  columns: DatasetColumn[],
  layout?: ReportLayout,
): ReportResult {
  const byName = new Map(
    columns.map((column) => [column.columnName.toLowerCase(), column]),
  )
  return {
    ...result,
    columns: result.columns.map((column, index) => {
      const layoutColumn = layout?.columns[index]
      if (layoutColumn?.alias?.trim()) {
        return { ...column, label: layoutColumn.alias.trim() }
      }
      const field = (layoutColumn?.field ?? column.name).toLowerCase()
      const meta = byName.get(field) ?? byName.get(column.name.toLowerCase())
      return {
        ...column,
        label: localizedText(
          lang,
          meta?.displayName || column.label,
          meta?.displayNameArabic,
        ),
      }
    }),
  }
}

export function columnVisibleInLang(
  column: { locale?: string | null } | null | undefined,
  lang: Lang,
) {
  const locale = (column?.locale ?? 'default').trim().toLowerCase()
  if (!locale || locale === 'default' || locale === 'all') {
    return true
  }
  if (locale === 'en' || locale === 'english') {
    return lang === 'en'
  }
  if (locale === 'ar' || locale === 'arabic') {
    return lang === 'ar'
  }
  return true
}

export function resultForLang(
  result: ReportResult,
  layout: ReportLayout | undefined,
  lang: Lang,
): ReportResult {
  return {
    ...result,
    columns: result.columns.filter((column, index) => {
      if (column.hidden) {
        return true
      }
      return columnVisibleInLang(layout?.columns[index], lang)
    }),
  }
}

export function layoutForLang(layout: ReportLayout, lang: Lang): ReportLayout {
  return {
    ...layout,
    columns: layout.columns.filter((column) => columnVisibleInLang(column, lang)),
  }
}
